namespace GameTOP.Interface
{
    public interface iJogador
    {
         string Chuta();
         string Corre();
         string Passe();
    }
}